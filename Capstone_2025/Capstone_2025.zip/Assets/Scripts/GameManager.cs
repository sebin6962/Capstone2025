using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    //public static GameManager Instance;

    //[Header("�� ��ȯ �� ������ �Ŵ���")]
    //public HeldItemManager heldItemManager;
    //public StorageInventoryUIManager storageInventoryUIManager;
    //public DoGamUIManager doGamUIManager;

    //private void Awake()
    //{
    //    if (Instance == null)
    //    {
    //        Instance = this;
    //        DontDestroyOnLoad(gameObject);

    //        if (heldItemManager == null)
    //            heldItemManager = FindObjectOfType<HeldItemManager>();

    //        if (storageInventoryUIManager == null)
    //            storageInventoryUIManager = FindObjectOfType<StorageInventoryUIManager>();

    //        if (doGamUIManager == null)
    //            doGamUIManager = FindObjectOfType<DoGamUIManager>();

    //        Debug.Log("[GameManager] �Ŵ��� �ڵ� ���� �Ϸ�");
    //    }
    //    else
    //    {
    //        Destroy(gameObject); // �ߺ� ����
    //    }
    //}

}

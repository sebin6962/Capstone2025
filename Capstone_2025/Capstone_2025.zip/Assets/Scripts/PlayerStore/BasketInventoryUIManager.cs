using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BasketInventoryUIManager : MonoBehaviour
{
    public static BasketInventoryUIManager Instance;

    public GameObject basketPanel;
    public RectTransform panelTransform;
    public List<BasketInventorySlot> slots;
    public Vector3 offset = new(0, 2.5f, 0);

    private BasketInventory currentBasket;
    private Transform player;

    public bool IsOpen { get; private set; } = false;

    private HashSet<string> selectedItemNames = new();

    private List<int> selectedSlotIndices = new();

    [Header("���� ����")]
    public GameObject progressBarPrefab;
    public GameObject resultItemPrefab;
    public Transform worldCanvasParent;

    private void Awake()
    {
        if (Instance == null) Instance = this;
    }

    public void OpenBasketUI(BasketInventory basket, Transform playerTransform)
    {
        currentBasket = basket;
        player = playerTransform;

        // �ε�
        currentBasket.Load();

        // UI ����
        UpdateUI();

        basketPanel.SetActive(true);
        IsOpen = true;
    }

    public void CloseBasketUI()
    {
        basketPanel.SetActive(false);
        IsOpen = false;
    }

    private void LateUpdate()
    {
        if (IsOpen && player != null)
        {
            Vector3 screenPos = Camera.main.WorldToScreenPoint(player.position + offset);
            panelTransform.position = screenPos;
        }
    }

    public void UpdateUI()
    {
        Dictionary<string, int> itemCounts = new();
        Dictionary<string, Sprite> itemSprites = new();

        for (int i = 0; i < currentBasket.itemNames.Count; i++)
        {
            string name = currentBasket.itemNames[i];
            Sprite sprite = currentBasket.itemSprites[i];

            if (!itemCounts.ContainsKey(name))
            {
                itemCounts[name] = 1;
                itemSprites[name] = sprite;
            }
            else
            {
                itemCounts[name]++;
            }
        }

        int index = 0;
        foreach (var pair in itemCounts)
        {
            if (index >= slots.Count) break;
            slots[index].SetItem(pair.Key, itemSprites[pair.Key], pair.Value);
            slots[index].slotIndex = index;
            index++;
        }

        for (int i = index; i < slots.Count; i++)
        {
            slots[i].Clear();
        }
    }

    public void OnSlotClicked(int index)
    {
        if (index >= currentBasket.itemNames.Count) return;

        string itemName = slots[index].itemName;
        int removeIndex = currentBasket.itemNames.IndexOf(itemName);

        // ���� UI ���� ������ �ٱ��� �� ���� �̵�
        if (PlayerStoreBoxInventoryUIManager.Instance.IsOpen())
        {
            Debug.Log($"[�ٱ��� �� ����] {itemName}");

            if (removeIndex != -1)
            {
                currentBasket.itemNames.RemoveAt(removeIndex);
                currentBasket.itemSprites.RemoveAt(removeIndex);

                StorageInventory.Instance.AddItem(itemName, 1);

                UpdateUI();
                PlayerStoreBoxInventoryUIManager.Instance.UpdateSlots();
            }
            else
            {
                Debug.LogWarning($"[����] {itemName}�� ã�� �� �����ϴ� (removeIndex = -1)");
            }

            return;
        }

        // ���۱� ��ó�� �� ����/����
        if (PlayerInteract.Instance.IsNearMaker())
        {
            var slot = slots[index];

            if (selectedSlotIndices.Contains(index))
            {
                selectedSlotIndices.Remove(index);
                slot.Deselect();
                Debug.Log($"[���� ����] {itemName}");
            }
            else
            {
                selectedSlotIndices.Add(index);
                slot.Select();
                Debug.Log($"[����] {itemName}");
            }

            return;
        }

    }

    public void StartCrafting(MakerInfo maker)
    {
        Debug.Log($"[���� �����] ���õ� ���� ��: {selectedSlotIndices.Count}");

        foreach (int idx in selectedSlotIndices)
        {
            Debug.Log($"���õ� ���� �ε���: {idx}");
        }

        if (selectedSlotIndices.Count == 0)
        {
            Debug.LogWarning("[���� ����] ���õ� ������ ����");
            return;
        }

        // ���� ����� ù ��° ���õ� ���������� ����
        int resultIndex = selectedSlotIndices[0];
        string resultItemName = currentBasket.itemNames[resultIndex];
        Sprite resultSprite = currentBasket.itemSprites[resultIndex];

        // ���� �� ������ �ε����� ���ĵ� ���·� ������
        selectedSlotIndices.Sort((a, b) => b.CompareTo(a)); // ���� ����

        foreach (int index in selectedSlotIndices)
        {
            if (index < currentBasket.itemNames.Count)
            {
                currentBasket.itemNames.RemoveAt(index);
                currentBasket.itemSprites.RemoveAt(index);
            }
        }

        selectedSlotIndices.Clear();
        UpdateUI();

        StartCoroutine(CraftingCoroutine(maker, resultItemName, resultSprite));

        // �ٱ��� UI �ݱ�
        CloseBasketUI();
    }

    private IEnumerator CraftingCoroutine(MakerInfo maker, string itemName, Sprite sprite)
    {
        Vector3 worldPos = maker.transform.position + new Vector3(0f, 1.2f, 0f);

        GameObject bar = Instantiate(progressBarPrefab, worldCanvasParent);
        bar.transform.position = worldPos;

        Transform fill = bar.transform.Find("Fill");
        Image fillImage = fill?.GetComponent<Image>();
        if (fillImage == null)
        {
            Debug.LogError("[����] ���൵ �� Fill ������Ʈ�� ã�� �� �����ϴ�.");
            yield break;
        }

        float timer = 0f;
        float duration = 3f;
        fillImage.fillAmount = 0f;

        while (timer < duration)
        {
            timer += Time.deltaTime;
            fillImage.fillAmount = Mathf.Clamp01(timer / duration);
            yield return null;
        }

        Destroy(bar);

        GameObject result = Instantiate(resultItemPrefab, worldPos + Vector3.up, Quaternion.identity);
        Image img = result.GetComponent<Image>();

        if (img != null)
        {
            img.sprite = sprite;
        }
        else
        {
            Debug.LogError("[���� ���] Image ������Ʈ�� ã�� �� �����ϴ�.");
        }


        ResultItem resultItem = result.AddComponent<ResultItem>();
        resultItem.itemName = itemName;

        UpdateUI();

        Debug.Log($"[���� �Ϸ�] ��� ����: {itemName}");
    }

    public bool TryAddItemToBasket(string itemName, Sprite sprite)
    {
        if (currentBasket == null) return false;
        bool added = currentBasket.AddItem(itemName, sprite);
        if (added) UpdateUI(); // �߰� ���� �� UI ����
        return added;
    }

    public void SetPlayer(Transform playerTransform)
    {
        this.player = playerTransform;
    }

    public bool CanSelectSlot()
    {
        return PlayerInteract.Instance.IsNearMaker(); // ���۱�� ���� ���¸�
    }

    public void OnItemSelected(string itemName, int slotIndex)
    {
        if (!selectedSlotIndices.Contains(slotIndex))
            selectedSlotIndices.Add(slotIndex);
    }

    public void OnItemDeselected(string itemName, int slotIndex)
    {
        selectedSlotIndices.Remove(slotIndex);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakerInfo : MonoBehaviour
{
    public string makerId;
    public GameObject currentResultObject; // ��� ������Ʈ ������
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
